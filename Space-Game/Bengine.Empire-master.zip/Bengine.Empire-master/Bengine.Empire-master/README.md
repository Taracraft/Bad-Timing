# Bengine Empire Tutorial-Package

This package shows the the basic functionality of Bengine's Package API.

## Features
Displays a grid view of all planets along with buildings, ships and defense.
Currently only german translation.

## Installation
1.  Copy the content of all sup-directories into your Bengine root folder.
2.  Delete the caches file var/cache/meta.cache.php.

## Requirements
The package requires Bengine 0.30 or higher