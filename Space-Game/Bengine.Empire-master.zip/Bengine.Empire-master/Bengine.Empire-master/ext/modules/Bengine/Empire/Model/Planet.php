<?php

class Bengine_Empire_Model_Planet extends Bengine_Game_Model_Planet
{
	// This class has benn rewritten from game/model_planet empire/model_planet.
	// You can now override public and protected methods of the parent class.
}