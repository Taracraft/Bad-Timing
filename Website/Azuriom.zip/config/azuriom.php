<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Azuriom Game
    |--------------------------------------------------------------------------
    |
    | This is the game used by the website. It should NOT be changed after
    | the installation !
    |
    */

    'game' => env('AZURIOM_GAME'),
];
