@extends('errors::layout')

@section('title', trans('errors.503.title'))
@section('code', '503')
@section('message', trans('errors.503.message'))
